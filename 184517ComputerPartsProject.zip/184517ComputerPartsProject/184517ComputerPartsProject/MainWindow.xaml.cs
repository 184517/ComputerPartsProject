﻿/*Jordan Ross
 * February 25, 2019
 * Main Window of Computer Parts Project
 * Menu to get to each window
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace _184517ComputerPartsProject
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void btnCPU_Click(object sender, RoutedEventArgs e)
        {
            CPU Cw = new CPU();
            Cw.ShowDialog();
        }

        private void btnMotherboard_Click(object sender, RoutedEventArgs e)
        {
            Motherboard Cw = new Motherboard();
            Cw.ShowDialog();
        }

        private void btnMemory_Click(object sender, RoutedEventArgs e)
        {
            Memory Cw = new Memory();
            Cw.ShowDialog();
        }

        private void btnGraphicsCard_Click(object sender, RoutedEventArgs e)
        {
            Graphics_Card Cw = new Graphics_Card();
            Cw.ShowDialog();
        }

        private void btnOpticalDrive_Click(object sender, RoutedEventArgs e)
        {
            Optical_Drive Cw = new Optical_Drive();
            Cw.ShowDialog();
        }

        private void btnStorage_Click(object sender, RoutedEventArgs e)
        {
            Storage Cw = new Storage();
            Cw.ShowDialog();
        }

        private void btnCasePowerSupply_Click(object sender, RoutedEventArgs e)
        {
            Case_PowerSupply Cw = new Case_PowerSupply();
            Cw.ShowDialog();
        }
    }
}
